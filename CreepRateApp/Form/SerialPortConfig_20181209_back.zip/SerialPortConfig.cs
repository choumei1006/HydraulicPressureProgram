﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO.Ports;

namespace CreepRateApp.Form
{
    public partial class SerialPortConfig : DevExpress.XtraEditors.XtraForm
    {
        //定义端口类
        private SerialPort ComDevice = new SerialPort();

        Properties.Settings settings = Properties.Settings.Default;

        public SerialPortConfig()
        {
            try
            {
                ComDevice.Close();
            }
            catch { }

            InitializeComponent();

            Init();
        }

        /// <summary>
        /// 配置初始化
        /// </summary>
        private void Init()
        {
            string[] portsList = SerialPort.GetPortNames();
            if (portsList.Length > 0)
            {
                this.comboBoxEdit1.Properties.Items.Clear();
                this.comboBoxEdit1.Properties.Items.AddRange(portsList);
                this.comboBoxEdit1.EditValue = portsList[0];

                this.comboBoxEdit2.Text = settings.BaudRate;
                this.comboBoxEdit3.Text = settings.DataBits;
                this.comboBoxEdit4.Text = settings.StopBits;
                this.comboBoxEdit5.Text = settings.Parity;

                if (settings.CodeType == "1")
                    this.checkEdit1.Checked = true;
                else if (settings.CodeType == "2")
                    this.checkEdit2.Checked = true;
                else if (settings.CodeType == "3")
                    this.checkEdit3.Checked = true;
                else if (settings.CodeType == "4")
                    this.checkEdit4.Checked = true;
                else
                    this.checkEdit1.Checked = true;

                //向ComDevice.DataReceived（是一个事件）注册一个方法Com_DataReceived，当端口类接收到信息时时会自动调用Com_DataReceived方法
                ComDevice.DataReceived += new SerialDataReceivedEventHandler(Com_DataReceived);
            }
            else
            {
                XtraMessageBox.Show("未检测到串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
            }
        }

        /// <summary>
        /// 一旦ComDevice.DataReceived事件发生，就将从串口接收到的数据显示到接收端对话框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Com_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //开辟接收缓冲区
            byte[] ReDatas = new byte[ComDevice.BytesToRead];
            //从串口读取数据
            ComDevice.Read(ReDatas, 0, ReDatas.Length);
            //实现数据的解码与显示
            AddData(ReDatas);
        }

        /// <summary>
        /// 解码过程
        /// </summary>
        /// <param name="data">串口通信的数据编码方式因串口而异，需要查询串口相关信息以获取</param>
        public void AddData(byte[] data)
        {
            if (checkEdit1.Checked)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < data.Length; i++)
                {
                    sb.AppendFormat("{0:x2}" + " ", data[i]);
                }
                AddContent(sb.ToString().ToUpper());
            }
            else if (checkEdit2.Checked)
            {
                AddContent(new ASCIIEncoding().GetString(data));
            }
            else if (checkEdit3.Checked)
            {
                AddContent(new UTF8Encoding().GetString(data));
            }
            else if (checkEdit4.Checked)
            {
                AddContent(new UnicodeEncoding().GetString(data));
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < data.Length; i++)
                {
                    sb.AppendFormat("{0:x2}" + " ", data[i]);
                }
                AddContent(sb.ToString().ToUpper());
            }
        }

        /// <summary>
        /// 接收端对话框显示消息
        /// </summary>
        /// <param name="content"></param>
        private void AddContent(string content)
        {
            BeginInvoke(new MethodInvoker(delegate
            {
                this.memoEdit1.Text = this.memoEdit1.Text + content + "\r\n";
            }));
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            try
            {
                ComDevice.Close();
            }
            catch { }

            //设置串口相关属性
            //端口
            ComDevice.PortName = comboBoxEdit1.SelectedItem.ToString();
            //波特率
            ComDevice.BaudRate = Convert.ToInt32(comboBoxEdit2.SelectedItem.ToString());
            //数据位
            ComDevice.DataBits = Convert.ToInt32(comboBoxEdit3.SelectedItem.ToString());
            //停止位
            ComDevice.StopBits = (StopBits)Convert.ToInt32(comboBoxEdit4.SelectedItem.ToString());
            //校验
            if (comboBoxEdit5.SelectedIndex.ToString() == "None")
                ComDevice.Parity = Parity.None;
            else if (comboBoxEdit5.SelectedIndex.ToString() == "Odd")
                ComDevice.Parity = Parity.Odd;
            else if (comboBoxEdit5.SelectedIndex.ToString() == "Even")
                ComDevice.Parity = Parity.Even;
            else if (comboBoxEdit5.SelectedIndex.ToString() == "Mark")
                ComDevice.Parity = Parity.Mark;
            else if (comboBoxEdit5.SelectedIndex.ToString() == "Space")
                ComDevice.Parity = Parity.Space;
            else
                ComDevice.Parity = Parity.None;

            try
            {
                //开启串口
                ComDevice.Open();
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show(ex.Message, "未能成功开启串口", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        /// <summary>
        /// 保存设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void simpleButton2_Click(object sender, EventArgs e)
        {
            //端口
            if (!string.IsNullOrWhiteSpace(comboBoxEdit1.Text))
            {
                settings.PortName = comboBoxEdit1.Text;
                GlobalValue.PortName = comboBoxEdit1.Text;
            }
            //波特率
            if (!string.IsNullOrWhiteSpace(comboBoxEdit2.Text))
            {
                settings.BaudRate = comboBoxEdit2.Text;
                GlobalValue.BaudRate = comboBoxEdit2.Text;
            }
            //数据位
            if (!string.IsNullOrWhiteSpace(comboBoxEdit3.Text))
            {
                settings.DataBits = comboBoxEdit3.Text;
                GlobalValue.DataBits = comboBoxEdit3.Text;
            }
            //停止位
            if (!string.IsNullOrWhiteSpace(comboBoxEdit4.Text))
            {
                settings.StopBits = comboBoxEdit4.Text;
                GlobalValue.StopBits = comboBoxEdit4.Text;
            }
            //校验方式
            if (!string.IsNullOrWhiteSpace(comboBoxEdit5.Text))
            {
                if (settings.Parity == "None")
                    GlobalValue.Parity = Parity.None;
                else if (settings.Parity == "Odd")
                    GlobalValue.Parity = Parity.Odd;
                else if (settings.Parity == "Even")
                    GlobalValue.Parity = Parity.Even;
                else if (settings.Parity == "Mark")
                    GlobalValue.Parity = Parity.Mark;
                else if (settings.Parity == "Space")
                    GlobalValue.Parity = Parity.Space;
                else
                    GlobalValue.Parity = Parity.None;
            }
            //编码方式
            string codeType = "1";
            if (checkEdit1.Checked)
                codeType = "1";
            else if (checkEdit2.Checked)
                codeType = "2";
            else if (checkEdit3.Checked)
                codeType = "3";
            else if (checkEdit4.Checked)
                codeType = "4";
            else
                codeType = "1";
            settings.CodeType = codeType;
            GlobalValue.CodeType = codeType;

            settings.Save();

            XtraMessageBox.Show("串口配置成功,软件需要重新启动配置", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Close();
        }
    }
}